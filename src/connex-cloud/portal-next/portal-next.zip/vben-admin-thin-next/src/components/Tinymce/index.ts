import { withInstall } from '/@/utils/index';
import tinymce from './src/Editor.vue';

export const Tinymce = withInstall(tinymce);
